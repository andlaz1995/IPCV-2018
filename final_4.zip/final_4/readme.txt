To compile each subtask, run:

make [{task1,task2,task3,task4}] 

And then to run the task for a given dart image:

./a.out dart0.jpg